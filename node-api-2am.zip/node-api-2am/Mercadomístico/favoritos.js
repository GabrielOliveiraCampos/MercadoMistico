document.querySelectorAll('.add-to-favorites').forEach(button => {
    button.addEventListener('click', async function() {
        const productId = this.getAttribute('data-id');
        const usuarioId = JSON.parse(localStorage.getItem('informacoes')).Idusuario;

        try {
            const response = await fetch('http://localhost:3000/favoritos/adicionar', {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ UsuarioId: usuarioId, ProdutoId: productId })
            });

            const result = await response.json();

            if (result.success) {
                alert('Produto adicionado aos favoritos com sucesso!');
                window.location.href = 'favoritos.html';  
            } else {
                alert(result.message);
            }
        } catch (error) {
            console.error('Erro ao adicionar aos favoritos:', error);
        }
    });
});


window.onload = async function() {
    const usuarioId = JSON.parse(localStorage.getItem('informacoes')).Idusuario;

    if (!usuarioId) {
        alert('Usuário não está logado!');
        window.location.href = 'login.html';
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/favoritos/listar/${usuarioId}`);
        const result = await response.json();

        if (result.success) {
            const favoritosDiv = document.getElementById('favoritos');
            favoritosDiv.innerHTML = ''; 

            result.data.forEach(produto => {
                const produtoElement = document.createElement('div');
                produtoElement.classList.add('produto-favorito');
                produtoElement.innerHTML = `
                    <img src="${produto.image}" alt="${produto.Tituloproduto}">
                    <p>${produto.Tituloproduto}</p>
                    <p>R$${produto.valor.toFixed(2)}</p>
                `;
                favoritosDiv.appendChild(produtoElement);
            });
        } else {
            alert('Erro ao carregar produtos favoritos');
        }
    } catch (error) {
        console.error('Erro ao carregar favoritos:', error);
        alert('Erro ao carregar os produtos favoritos.');
    }
};

if (result.success) {
    alert('Produto adicionado aos favoritos com sucesso!');
    carregarFavoritos();
}
