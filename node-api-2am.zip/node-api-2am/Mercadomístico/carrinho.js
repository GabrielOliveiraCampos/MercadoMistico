document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', async function() {
        const productId = this.getAttribute('data-id'); 
        const usuarioId = JSON.parse(localStorage.getItem('informacoes')).Idusuario;  

        if (!usuarioId) {
            alert('Usuário não está logado!');
            window.location.href = 'login.html'; 
            return;
        }

        console.log("Botão clicado: ", productId);

        try {
            const response = await fetch('http://localhost:3000/carrinho/adicionar', {
                method: 'POST',
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ UsuarioId: usuarioId, ProdutoId: productId })  
            });

            const result = await response.json();

            if (result.success) {
                alert('Produto adicionado ao carrinho com sucesso!');
                window.location.href = 'carrinho.html'; 
            } else {
                alert(result.message);  
            }
        } catch (error) {
            console.error('Erro ao adicionar ao carrinho:', error); 
        }
    });
});


window.onload = async function() {
    const usuario = JSON.parse(localStorage.getItem('informacoes'));  
    const usuarioId = usuario ? usuario.Idusuario : null;

    if (!usuarioId) {
        alert('Usuário não identificado. Por favor, faça login.');
        window.location.href = 'login.html'; 
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/carrinho/listar/${usuarioId}`);
        const result = await response.json();

        if (result.success) {
            const carrinhoDiv = document.getElementById('carrinho');
            let total = 0;

            carrinhoDiv.innerHTML = '';

            result.data.forEach(produto => {
                const produtoElement = document.createElement('div');
                produtoElement.innerHTML = `
                    <img src="${produto.image}" width="100px">
                    <p>${produto.Tituloproduto}</p>
                    <p>R$${produto.valor.toFixed(2)}</p>
                `;
                carrinhoDiv.appendChild(produtoElement);
                total += produto.valor;
            });

            document.getElementById('totalValue').innerText = total.toFixed(2);
        } else {
            alert('Erro ao carregar produtos do carrinho');
        }
    } catch (error) {
        console.error('Erro ao carregar o carrinho:', error);
        alert('Erro ao carregar o carrinho.');
    }
};

document.getElementById('checkout-button').addEventListener('click', function() {
    window.location.href = 'checkout.html';  
});

window.onload = async function() {
    const usuario = JSON.parse(localStorage.getItem('informacoes')); 
    const usuarioId = usuario ? usuario.Idusuario : null;

    if (!usuarioId) {
        alert('Usuário não identificado. Por favor, faça login.');
        window.location.href = 'login.html';  
        return;
    }

    try {
        const response = await fetch(`http://localhost:3000/carrinho/listar/${usuarioId}`);
        const result = await response.json();

        if (result.success) {
            const carrinhoDiv = document.getElementById('carrinho');
            let total = 0;
            carrinhoDiv.innerHTML = '';
            result.data.forEach(produto => {
                const produtoElement = document.createElement('div');
                produtoElement.innerHTML = `
                    <img src="${produto.image}" width="100px">
                    <p>${produto.Tituloproduto}</p>
                    <p>R$${produto.valor.toFixed(2)}</p>
                `;
                carrinhoDiv.appendChild(produtoElement);
                total += produto.valor;
            });

            document.getElementById('totalValue').innerText = total.toFixed(2);
            localStorage.setItem('totalCarrinho', total.toFixed(2));
        } else {
            alert('Erro ao carregar produtos do carrinho');
        }
    } catch (error) {
        console.error('Erro ao carregar o carrinho:', error);
        alert('Erro ao carregar o carrinho.');
    }
};
