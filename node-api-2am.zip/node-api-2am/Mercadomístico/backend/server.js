const express = require('express');
const cors = require('cors');

const porta = 3000;
const app = express();

app.use(cors());
app.use(express.json());

app.listen(porta, () => console.log(`Rodando na porta ${porta}`));

const connection = require('./db_config');
const upload = require('./multer')

app.post('/usuario/cadastrar', (request, response) => {
let params = [
  request.body.name,
  request.body.email,
  request.body.password,
  request.body.cpf_number,
  request.body.tipo_usuario, 
  request.body.status 
];

let query = "INSERT INTO Usuarios(name, email, password, cpf_number, tipo_usuario, status) VALUES(?,?,?,?,?,?);";

connection.query(query, params, (err, results) => {
  if (results) {
    response
      .status(201)
      .json({
        success: true,
        message: "Usuário cadastrado com sucesso!",
        data: results
      });
  } else {
    response
      .status(400)
      .json({
        success: false,
        message: "Falha ao cadastrar usuário.",
        data: err
      });
  }
});
});

app.get('/usuarios/listar', (request, response) => {
let query = "SELECT * FROM Usuarios";
const { status } = request.query;

if (status) {
  query += " WHERE status = ?";
}

connection.query(query, [status], (err, results) => {
  if (results) {
    response
      .status(200)
      .json({
        success: true,
        message: "Usuários listados com sucesso!",
        data: results
      });
  } else {
    response
      .status(400)
      .json({
        success: false,
        message: "Erro ao listar usuários.",
        data: err
      });
  }
});
});

app.put('/usuarios/editar/:Idusuario', (request, response) => {
const { name, email, password, cpf_number, status, tipo_usuario } = request.body;
const { Idusuario } = request.params;

if (!Idusuario) {
  return response.status(400).json({ success: false, message: "ID de usuário não fornecido." });
}

let fieldsToUpdate = [];
let params = [];

if (name) {
  fieldsToUpdate.push('name = ?');
  params.push(name);
}
if (email) {
  fieldsToUpdate.push('email = ?');
  params.push(email);
}
if (password) {
  fieldsToUpdate.push('password = ?');
  params.push(password);
}
if (cpf_number) {
  fieldsToUpdate.push('cpf_number = ?');
  params.push(cpf_number);
}
if (status) {
  fieldsToUpdate.push('status = ?');
  params.push(status);
}
if (tipo_usuario) {
  fieldsToUpdate.push('tipo_usuario = ?');
  params.push(tipo_usuario);
}

params.push(Idusuario);

const query = `UPDATE Usuarios SET ${fieldsToUpdate.join(', ')} WHERE Idusuario = ?`;

connection.query(query, params, (err, results) => {
  if (results) {
    response
      .status(200)
      .json({
        success: true,
        message: "Usuário atualizado com sucesso!",
        data: results
      });
  } else {
    console.error('Erro ao atualizar usuário:', err); 
    response
      .status(400)
      .json({
        success: false,
        message: "Erro ao atualizar usuário.",
        data: err
      });
  }
});
});

app.delete('/usuario/deletar/:Idusuario', (request, response) => {
  let params = Array(
    request.params.Idusuario
  );

  let query = "DELETE FROM Usuarios WHERE Idusuario = ?";

  connection.query(query, params, (err, results) => {
    if(results) {
      response
        .status(200)
        .json({
          success: true,
          message: "Sucesso",
          data: results
        });
    } else {
      response
        .status(400)
        .json({
          success: false,
          message: "Sem Sucesso",
          data: err
        });
    }
  });
});

app.post('/usuario/login', (request, response) => {

const { email, password } = request.body;
const query = "SELECT * FROM Usuarios WHERE email = ? AND password = ?";
const params = [email, password];

connection.query(query, params, (err, results) => {
    if (results && results.length > 0) {
        const user = results[0]; 
        response
            .status(200)
            .json({
                success: true,
                message: "Login com sucesso!",
                tipo_usuario: user.tipo_usuario, 
                data: user 
            });
    } else {
        response
            .status(401)
            .json({
                success: false,
                message: "Email ou senha incorretos!",
            });
    }
});
});

app.post('/produto/cadastrar', upload.single("file"), (request, response) => {
  const imageFilename = request.file ? request.file.filename : 'default_image.jpg'; 

  let params = [
      request.body.nomeProduto,
      request.body.valor,
      imageFilename 
  ];

  let query = "INSERT INTO Produtos(Tituloproduto, valor, image) VALUES (?, ?, ?);";

  connection.query(query, params, (err, results) => {
      if (results) {
          response.status(201).json({
              success: true,
              message: "Produto cadastrado com sucesso",
              data: results
          });
      } else {
          response.status(400).json({
              success: false,
              message: "Erro ao cadastrar produto",
              data: err
          });
      }
  });
});

app.get('/produtos/listar', (request, response) => {
const query = "SELECT * FROM Produtos";

connection.query(query, (err, results) => {
    if (results) {
        response
            .status(200)
            .json({
                success: true,
                message: "Produtos listados com sucesso",
                data: results
            });
    } else {
        response
            .status(400)
            .json({
                success: false,
                message: "Erro ao listar produtos",
                data: err
            });
    }
});
});

app.put('/produto/editar/:produtoId', (request, response) => {
  const { Tituloproduto, valor } = request.body;  
  const { produtoId } = request.params;

  if (!produtoId) {
      return response.status(400).json({ success: false, message: "ID de produto não fornecido." });
  }

  let query = "UPDATE Produtos SET Tituloproduto = ?, valor = ? WHERE Produtoid = ?";

  let params = [Tituloproduto, valor, produtoId];

  connection.query(query, params, (err, results) => {
      if (err) {
          return response.status(400).json({
              success: false,
              message: "Erro ao atualizar produto",
              data: err
          });
      }

      response.status(200).json({
          success: true,
          message: "Produto atualizado com sucesso",
          data: results
      });
  });
});

app.delete('/Produtos/deletar/:ProdutoId', (request, response) => {
let params = [
    request.params.ProdutoId
];

let query = "DELETE FROM Produtos WHERE ProdutoId = ?";

connection.query(query, params, (err, results) => {
    if (results) {
        response
            .status(200)
            .json({
                success: true,
                message: "Produto deletado com sucesso",
                data: results
            });
    } else {
        response
            .status(400)
            .json({
                success: false,
                message: "Erro ao deletar produto",
                data: err
            });
    }
});
});

app.post('/carrinho/adicionar', (request, response) => {
  const { UsuarioId, ProdutoId } = request.body;

  if (!UsuarioId || !ProdutoId) {
      return response.status(400).json({
          success: false,
          message: 'Usuário ou produto não informado.'
      });
  }

  const query = 'INSERT INTO Carrinho (UsuarioId, ProdutoId) VALUES (?, ?)';

  connection.query(query, [UsuarioId, ProdutoId], (err, results) => {
      if (err) {
          return response.status(500).json({
              success: false,
              message: 'Erro ao adicionar ao carrinho.',
              data: err
          });
      }

      response.status(201).json({
          success: true,
          message: 'Produto adicionado ao carrinho com sucesso!',
          data: results
      });
  });
});

app.get('/carrinho/listar/:UsuarioId', (request, response) => {
  const { UsuarioId } = request.params;

  const query = `
      SELECT p.Tituloproduto, p.valor, p.image 
      FROM Carrinho c
      JOIN produtos p ON c.ProdutoId = p.Produtoid
      WHERE c.UsuarioId = ?;
  `;

  connection.query(query, [UsuarioId], (err, results) => {
      if (err) {
          return response.status(500).json({
              success: false,
              message: 'Erro ao listar produtos do carrinho.',
              data: err
          });
      }

      response.status(200).json({
          success: true,
          message: 'Produtos listados com sucesso!',
          data: results
      });
  });
});

app.put('/carrinho/editar/:ProdutoId', (req, res) => {
  const { quantidade, UsuarioId } = req.body;
  const { ProdutoId } = req.params;

  console.log("ProdutoId:", ProdutoId);
  console.log("UsuarioId:", UsuarioId);
  console.log("Quantidade:", quantidade);

  if (isNaN(ProdutoId) || isNaN(quantidade) || isNaN(UsuarioId)) {
      return res.status(400).json({
          success: false,
          message: "Valores inválidos fornecidos."
      });
  }

  const query = "UPDATE Carrinho SET quantidade = ? WHERE ProdutoId = ? AND UsuarioId = ?";
  connection.query(query, [quantidade, parseInt(ProdutoId), UsuarioId], (err, results) => {
      if (err) {
          return res.status(500).json({
              success: false,
              message: "Erro ao atualizar produto no carrinho",
              data: err
          });
      }

      res.status(200).json({
          success: true,
          message: "Produto atualizado no carrinho",
          data: results
      });
  });
});


app.delete('/carrinho/deletar/:ProdutoId', (request, response) => {
  const { ProdutoId } = request.params;
  const { UsuarioId } = request.body;

  const query = "DELETE FROM Carrinho WHERE ProdutoId = ? AND UsuarioId = ?";

  connection.query(query, [ProdutoId, UsuarioId], (err, results) => {
      if (results) {
          response
              .status(200)
              .json({
                  success: true,
                  message: "Produto removido do carrinho",
                  data: results
              });
      } else {
          response
              .status(400)
              .json({
                  success: false,
                  message: "Erro ao remover produto do carrinho",
                  data: err
              });
      }
  });
});

app.post('/favoritos/adicionar', (request, response) => {
  const { UsuarioId, ProdutoId } = request.body;

  if (!UsuarioId || !ProdutoId) {
      return response.status(400).json({
          success: false,
          message: 'Usuário ou produto não informado.'
      });
  }

  const query = 'INSERT INTO Favoritos (UsuarioId, ProdutoId) VALUES (?, ?)';

  connection.query(query, [UsuarioId, ProdutoId], (err, results) => {
      if (err) {
          return response.status(500).json({
              success: false,
              message: 'Erro ao adicionar aos favoritos.',
              data: err
          });
      }

      response.status(201).json({
          success: true,
          message: 'Produto adicionado aos favoritos com sucesso!',
          data: results
      });
  });
});

app.get('/favoritos/listar/:UsuarioId', (request, response) => {
  const { UsuarioId } = request.params;

  const query = `
      SELECT p.Tituloproduto, p.valor, p.image 
      FROM Favoritos f
      JOIN Produtos p ON f.ProdutoId = p.Produtoid
      WHERE f.UsuarioId = ?;
  `;

  connection.query(query, [UsuarioId], (err, results) => {
      if (err) {
          return response.status(500).json({
              success: false,
              message: 'Erro ao listar produtos favoritos.',
              data: err
          });
      }

      response.status(200).json({
          success: true,
          message: 'Produtos favoritos listados com sucesso!',
          data: results
      });
  });
});
