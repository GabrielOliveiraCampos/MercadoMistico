async function CadastrarProduto(event) {
    event.preventDefault();

    const nomeProduto = document.getElementById('title').value;
    const valor = document.getElementById('price').value;

    const file = document.getElementById("file").files[0]
    let formData = new FormData(
    )
    formData.append("title", nomeProduto)
    formData.append("valor", valor)
    formData.append("file", file)

    try {
        const response = await fetch('http://localhost:3000/produto/cadastrar', {
            method: 'POST',
            body: formData 
        });

        const result = await response.json();

        if (result.success) {
            alert('Produto cadastrado com sucesso!');
            carregarProdutos(); 
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Erro ao cadastrar produto:', error);
    }
}
window.onload = carregarProdutos;

async function cadastrar(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const cpf_number = document.getElementById('cpf_number').value;

    const data = { name, email, password, cpf_number };

    try {
        const response = await fetch('http://localhost:3000/usuario/cadastrar', {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            alert('Usuário cadastrado com sucesso!');
            window.location.assign('login.html'); 
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Erro ao cadastrar usuário:', error);
    }
}

async function login(event) {
    event.preventDefault();

    const email = document.getElementById('login_email').value;
    const password = document.getElementById('login_password').value;

    const data = { email, password };

    try {
        const response = await fetch('http://localhost:3000/usuario/login', {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });
    
        const results = await response.json(); 
    
        if (results.success) {
            localStorage.setItem('informacoes', JSON.stringify(results.data));
            alert('Login com sucesso');
            window.location.assign('index.html'); 
        } else {
            alert(results.message);
        }
    } catch (error) {
        console.error('Erro ao fazer login:', error);
    }
 }    

if (results.success) {
    localStorage.setItem('informacoes', JSON.stringify(results.data));
}

async function carregarProdutos() {
    try {
        const response = await fetch('http://localhost:3000/produtos/listar');
        const result = await response.json();
        
        if (result.success) {
            const produtosContainer = document.getElementById('card-produto');
            produtosContainer.innerHTML = ''; 

            result.data.forEach(produto => {
                const produtoDiv = document.createElement('div');
                produtoDiv.classList.add('produto');
                produtoDiv.innerHTML = `
                    <img src="uploads/${produto.imagemProduto}" alt="${produto.nomeProduto}" width="200px" height="150px">
                    <p>${produto.nomeProduto}</p>
                    <span>R$${produto.valor}</span>
                    <button class="add-to-cart" data-id="${produto.id}" data-nome="${produto.nomeProduto}" data-preco="${produto.valor}">Adicionar ao Carrinho</button>
                `;
                
                produtosContainer.appendChild(produtoDiv);
            });
        } else {
            alert('Erro ao carregar produtos');
        }
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
    }
}
window.onload = carregarProdutos;




