CREATE DATABASE  MercadoMistico;
USE MercadoMistico;

CREATE TABLE usuarios (
    Idusuario INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    cpf_number BIGINT NOT NULL UNIQUE,
    status ENUM('Ativo', 'Inativo') NOT NULL,
    tipo_usuario ENUM('usuario', 'admin') NOT NULL
);

CREATE TABLE produtos (
    Produtoid INT AUTO_INCREMENT PRIMARY KEY,
    Tituloproduto VARCHAR(255) NOT NULL,
    valor DOUBLE NOT NULL,
    image TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Carrinho (
    id_carrinho INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    UsuarioId INT NOT NULL,
    ProdutoId INT NOT NULL,
    
    FOREIGN KEY (ProdutoId) REFERENCES produtos(Produtoid),
    FOREIGN KEY (UsuarioId) REFERENCES usuarios(Idusuario)
);

CREATE TABLE Favoritos (
    IdFavorito INT AUTO_INCREMENT PRIMARY KEY,
    UsuarioId INT NOT NULL,
    ProdutoId INT NOT NULL,
    FOREIGN KEY (UsuarioId) REFERENCES Usuarios(Idusuario),
    FOREIGN KEY (ProdutoId) REFERENCES Produtos(Produtoid)
);