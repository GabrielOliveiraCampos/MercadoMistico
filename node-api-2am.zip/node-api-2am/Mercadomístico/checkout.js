window.onload = function() {
    const userId = localStorage.getItem('userId'); 
    const totalCarrinho = localStorage.getItem('totalCarrinho');
    if (totalCarrinho) {
        document.getElementById('total-price').innerText = totalCarrinho;
    }

    fetch(`/carrinho/${userId}`)
        .then(response => response.json())
        .then(data => {
            const checkoutItemsDiv = document.getElementById('checkout-items');
            let total = 0;

            data.produtos.forEach(produto => {
                const produtoElement = document.createElement('div');
                produtoElement.innerHTML = `
                    <p>${produto.Tituloproduto}</p>
                    <p>R$${produto.valor.toFixed(2)}</p>
                `;
                checkoutItemsDiv.appendChild(produtoElement);
                total += produto.valor;
            });
            document.getElementById('total-price').innerText = total.toFixed(2);
        })
        .catch(error => console.error('Erro:', error));
};
