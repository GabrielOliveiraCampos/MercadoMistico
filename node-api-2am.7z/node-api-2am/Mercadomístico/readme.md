#Mercadomístico
Grupo: Gabriel Campos e Mirella Rezes
Turma:2AM

Introdução: Esse projeto mostra um banco de dados chamado "Mercadomístico", que é projetado para administrar informações sobre usuários, produtos, carrinhos de compras e registros de compras em um mercado mistico. Para armazenar e gerenciar esses dados o banco de dados faz uso do MySQL.

As informações necessárias para o projeto estão nos seguintes arquivos:
Banco de dados =  Mercadomístico/Bancodedados.sql
API e Server = Mercadomístico/src/server.js

Pacotes Node utilizados: nodemon, dotenv, cors, express, mysql2

Instruções de Instalação:
 Configuração do Banco de Dados
-Conecte-se ao servidor MySQL.
-Crie o banco de dados com o comando:CREATE DATABASE mercadomistico;
-Ative o banco de dadoscom o comando:USE mercadomistico;

Após isso será criado as tabelas com seus dados, aonde vai estar apresentado em:Mercadomístico/Bancodedados.sql

Tabela Usuários

CREATE TABLE Usuarios (
    Idusuario INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    cpf_number BIGINT,
    status ENUM('Ativo', 'Inativo') DEFAULT 'Ativo'
);

Esta tabela guarda informações sobre os usuários e ela inclui um identificador único que é o Idusuario, nome, email, senha, número de CPF e um status que pode ser 'Ativo' ou 'Inativo'.

os dados:

INSERT INTO Usuarios (name, email, password, cpf_number, status)
VALUES 
    ('Gabriell', 'gabriell@gmail.com', 'senha1', '88878888', 'Ativo'),
    ('Lucas', 'lucas@gmail.com', 'senha2', '99987766', 'Ativo'),
    ('Ana', 'ana@gmail.com', 'senha3', '55566677', 'Inativo');

Tabela Produtos

CREATE TABLE Produtos (
    ProdutoId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nomeProduto VARCHAR(255) NOT NULL,
    quantidade INT NOT NULL,
    descricaoProduto VARCHAR(255),
    valor FLOAT NOT NULL,
    status ENUM('Disponível', 'Indisponível') DEFAULT 'Disponível'
);

 Esta tabela mostra detalhes sobre os produtos e inclui um identificador único que é o ProdutoId, nome, descrição, quantidade, valor e um status que pode ser 'Disponível' ou 'Indisponível'.

 os dados:

 INSERT INTO Produtos (nomeProduto, descricaoProduto, quantidade, valor, status)
VALUES 
    ('Poção do Sonho Profundo', 'Uma poção para um sono profundo e restaurador', 50, 29.99, 'Disponível'),
    ('Elixir da Amizade Eterna', 'Elixir que fortalece os laços da amizade', 30, 29.99, 'Disponível');

Tabela Carrinho

CREATE TABLE Carrinho (
    CarrinhoId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Idusuario INT NOT NULL,
    ProdutoId INT NOT NULL,
    quantidade INT NOT NULL DEFAULT 1,
    dataAdicao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Idusuario) REFERENCES Usuarios(Idusuario),
    FOREIGN KEY (ProdutoId) REFERENCES Produtos(ProdutoId)
);

 Essa tabela registra os produtos adicionados pelos usuários e inclui um identificador único que é o CarrinhoId, o id do usuário, o id do produto, a quantidade e a data de adição, também tem as chaves estrangeiras que garantem que os ids do usuário e do produto se ligam aos que já existem.

 os dados:

 INSERT INTO Carrinho (Idusuario, ProdutoId, quantidade)
VALUES 
    (1, 1, 2), 
    (2, 2, 1); 

Tabela Compra

CREATE TABLE Compra (
    IdCompra INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    data_compra TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valor FLOAT NOT NULL,
    CarrinhoId INT NOT NULL,
    FOREIGN KEY (CarrinhoId) REFERENCES Carrinho(CarrinhoId)
);

Essa tabela guarda os registros de compras que foram realizadas e inclui um identificador único que é o IdCompra, a data da compra, o valor total e o ID do carrinho associado. A chave estrangeira garante que cada compra esteja vinculada a um carrinho existente.

os dados:

INSERT INTO Compra (valor, CarrinhoId)
VALUES 
    (59.98, 1), -- Compra do carrinho 1 com valor total de 59.98
    (29.99, 2); -- Compra do carrinho 2 com valor total de 29.99

Tabela Favoritos

CREATE TABLE Favoritos (
    IdFavoritos INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ProdutoId INT NOT NULL,
    UsuarioId INT NOT NULL,
    FOREIGN KEY (UsuarioId) REFERENCES Usuarios(Idusuario),
    FOREIGN KEY (ProdutoId) REFERENCES Produtos(ProdutoId)
);

A tabela favoritos guarda os produtos marcados como favoritos pelos usuários também inclui um identificador único que é o IdFavoritos, o id do produto e o id do usuário que adicionou o produto aos favoritos. também tem chaves estrangeiras mostrando que os IDs estejam corretos.

os dados:
INSERT INTO Favoritos (ProdutoId, UsuarioId)
VALUES 
    (1, 1), 
    (2, 2); 


As explicações referente a cada rota apresentada será documentada por dentro dele, os comentários serão feitos no server.js. Segue abaixo alguns exemplos de como utilizar as APIs.


                                  ROTA PARA USUÁRIOS
                                  
Rota de cadastrar usuário:
    Método: POST
    Rota: http://localhost:3000/usuario/cadastrar
{
  "name": "Teste Rota",
  "email": "Testerota@gmail.com",
  "password": "rota",
  "cpf_number": "11111111"
}

Rota para listar usuários:
Método: GET
Rota : http://localhost:3000/usuarios/listar


Rota para editar usuário:
Método: PUT 
Rota: http://localhost:3000/usuarios/editar/12
{
  "name": "Carlos Silva"
}

Rota para deletar um usuário:
Método: DELETE
http://localhost:3000/usuario/deletar/12 

                                        ROTA PARA PRODUTOS 

Rota para adicionar um produto:
Método: POST
Rota: http://localhost:3000/produto/cadastrar
{
  "nomeProduto": "Poção da Sorte",
  "descricaoProduto": "Aumenta a sorte",
  "quantidade": 100,
  "valor": 29.99
}

Rota para listar os produtos:
Método: GET
Rota: http://localhost:3000/produtos/listar

Rota para editar um produto:
Método: PUT
Rota: http://localhost:3000/produto/editar/12
{
  "valor": 58.99
}

Rota para deletar o produto:
Método: DELETE
Rota: http://localhost:3000/produto/deletar/12


Outras rotas sendo executadas, juntamente com uma interface administrativa para controle dos produtos.