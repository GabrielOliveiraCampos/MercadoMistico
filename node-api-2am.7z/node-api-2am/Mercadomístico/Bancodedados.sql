CREATE DATABASE  MercadoMistico;
USE MercadoMistico;

CREATE TABLE Usuarios (
    Idusuario INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    cpf_number BIGINT,
    status ENUM('Ativo', 'Inativo') DEFAULT 'Ativo'
);
INSERT INTO Usuarios (name, email, password, cpf_number, status)
VALUES 
    ('Gabriell', 'gabriell@gmail.com', 'senha1', '88878888', 'Ativo'),
    ('Lucas', 'lucas@gmail.com', 'senha2', '99987766', 'Ativo'),
    ('Ana', 'ana@gmail.com', 'senha3', '55566677', 'Inativo');

SELECT * FROM Usuarios;
DELETE FROM Usuarios;

CREATE TABLE Produtos (
    ProdutoId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nomeProduto VARCHAR(255) NOT NULL,
    quantidade INT NOT NULL,
    descricaoProduto VARCHAR(255),
    valor FLOAT NOT NULL,
    status ENUM('Disponível', 'Indisponível') DEFAULT 'Disponível'
);
INSERT INTO Produtos (nomeProduto, descricaoProduto, quantidade, valor, status)
VALUES 
    ('Poção do Sonho Profundo', 'Uma poção para um sono profundo e restaurador', 50, 29.99, 'Disponível'),
    ('Elixir da Amizade Eterna', 'Elixir que fortalece os laços da amizade', 30, 29.99, 'Disponível'),
    ('Poção do Sono Eterno', 'Uma poção poderosa para um sono profundo', 20, 29.99, 'Disponível'),
    ('Elixir da Paz Interior', 'Elixir para paz e tranquilidade mental', 15, 29.99, 'Disponível'),
    ('Tônico da Energia Vital', 'Revigorante para aumentar a energia', 40, 29.99, 'Disponível'),
    ('Elixir da Fortuna', 'Aumenta a sorte e fortuna do usuário', 25, 29.99, 'Disponível'),
    ('Elixir da Euforia', 'Promove uma sensação de euforia e bem-estar', 10, 29.99, 'Disponível'),
    ('Poção da Sorte Desperta', 'Aumenta a sorte em momentos cruciais', 5, 29.99, 'Disponível');
    
    SELECT * FROM Produtos;
    
    CREATE TABLE Carrinho (
    CarrinhoId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    Idusuario INT NOT NULL,
    ProdutoId INT NOT NULL,
    quantidade INT NOT NULL DEFAULT 1,
    dataAdicao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Idusuario) REFERENCES Usuarios(Idusuario),
    FOREIGN KEY (ProdutoId) REFERENCES Produtos(ProdutoId)
);

INSERT INTO Carrinho (Idusuario, ProdutoId, quantidade)
VALUES 
    (42, 11, 2), 
    (44, 12, 1); 

SELECT * FROM Carrinho;
    DELETE FROM carrinho;
    

CREATE TABLE Compra (
    IdCompra INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    data_compra TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valor FLOAT NOT NULL,
    CarrinhoId INT NOT NULL,
    FOREIGN KEY (CarrinhoId) REFERENCES Carrinho(CarrinhoId)
);

INSERT INTO Compra (valor, CarrinhoId)
VALUES 
    (59.98, 4), 
    (29.99, 5); 
    
    SELECT * FROM Compra;

CREATE TABLE Favoritos (
    IdFavoritos INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ProdutoId INT NOT NULL,
    UsuarioId INT NOT NULL,
    FOREIGN KEY (UsuarioId) REFERENCES Usuarios(Idusuario),
    FOREIGN KEY (ProdutoId) REFERENCES Produtos(ProdutoId)
);

INSERT INTO Favoritos (ProdutoId, UsuarioId)
VALUES 
    (11, 42), 
    (12, 44); 

SELECT * FROM Favoritos;

