// Função de Cadastro
async function cadastrar(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const cpf = document.getElementById('cpf_number').value;

    // Validação do CPF
    if (isNaN(cpf) || cpf.length !== 11) {
        alert('Por favor, insira um CPF válido com 11 dígitos.');
        return;
    }

    const data = { name, email, password, cpf_number: parseInt(cpf, 10) };

    try {
        const response = await fetch('http://localhost:3000/usuario/cadastrar', {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (result.success) {
            alert('Cadastro realizado com sucesso. Você será redirecionado para o login.');
            window.location.assign('login.html'); // Redireciona para a página de login
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Erro ao cadastrar:', error);
        alert('Ocorreu um erro durante o cadastro. Tente novamente mais tarde.');
    }
}

// Função de Login
async function login(event) {
    event.preventDefault();

    const email = document.getElementById('login_email').value;
    const password = document.getElementById('login_password').value;

    const data = { email, password };

    try {
        const response = await fetch('http://localhost:3000/usuario/login', {
            method: 'POST',
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        const results = await response.json();

        if (results.success) {
            alert('Login com sucesso');
            // Armazenar informações do usuário no localStorage
            localStorage.setItem('informacoes', JSON.stringify(results.data));

            // Redirecionar para a página inicial do site
            window.location.assign('index.html'); // Redireciona para a página inicial
        } else {
            alert(results.message);
        }
    } catch (error) {
        console.error('Erro ao fazer login:', error);
    }
}

window.addEventListener("load", () => {
    if (localStorage.getItem("informacoes")) {
        let html = document.getElementById("informacoes")
        let dados = JSON.parse(localStorage.getItem("informacoes"))

        dados.status === "admin"
            ? document.getElementById("Cadastrar_produto").style.display = "block"
            : document.getElementById("Cadastrar_produto").style.display = "none"
    }
})