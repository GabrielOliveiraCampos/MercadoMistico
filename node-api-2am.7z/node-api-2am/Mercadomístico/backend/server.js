const express = require('express');
const cors = require('cors');

const porta = 3000;
const app = express();

app.use(cors());
app.use(express.json());

app.listen(porta, () => console.log(`Rodando na porta ${porta}`));

const connection = require('./db_config');
app.use(express.urlencoded({ extended: true }));



//rota de cadastro de usuários

// Essa rota post foi criada para cadastrar um novo usuário no banco de dados, Quando a rota é acessada, 
//os dados do usuário sendo eles nome, email, senha e CPF são capturados do corpo da requisição que é o request.body.
//Assim os dados são usados para a execução e o servidor retorna como inserido.
// Se a atualização for bem-sucedida a resposta vai ser mostrada com o status 201 sendo sucedida
//Se tiver um erro a resposta é enviada com status 400 indicando falha  e o erro é retornado.
app.post('/usuario/cadastrar', (request, response) => {
    let params = Array(
        request.body.name,
        request.body.email,
        request.body.password,
        request.body.cpf_number
    );
    let query = "INSERT INTO Usuarios(name,email,password,cpf_number) VALUES(?,?,?,?);";

    connection.query(query,params, (err, results) => {
    if(results) {
        response
        .status(201)
        .json({
            success: true,
            message: "Sucesso", 
            data: results
        })
    } else {
        response
        .status(400)
        .json({
            success: false,
            message: "Sem Sucesso",
            data: err
        })
    }
    })
});

//Essa rota recupera todos os usuários cadastrados no banco de dados. Aonde ao ser executada a rota se a 
//consulta for sucedida o servidor retorna todos os usuários que estão cadastrados
// Se a atualização for sucedida a resposta é enviada com status 200 sendo bem sucedida
//Se tiver um erro a resposta é enviada com status 400 indicando falha  e o erro é retornado.
app.get('/usuarios/listar', (request, response) => {
    const query = "SELECT * FROM Usuarios";
  
    connection.query(query, (err, results) => {
      if(results) {
        response
          .status(200)
          .json({
            success: true,
            message: "Sucesso!",
            data: results
          });
      } else {
        response
          .status(400)
          .json({
            success: false,
            message: "Sem sucesso!",
            data: err
          });
      }
    });
  });

// Essa rota atualiza o nome de um usuário específico no banco.A rota utiliza o Idusuario na URL para 
//identificar qual registro vai ser atualizado e o novo nome fornecido no corpo (request.body.name). 
// a query executada : UPDATE Usuarios SET name = ? WHERE Idusuario = ?, atualiza o campo com o Idusuario 
//correspondente Se a atualização for bem-sucedida, a resposta é enviada com status 200 sendo bem sucedida
//Se ocorrer um erro a resposta é enviada com status 400 indicando falha  e o erro é retornado.

app.put('/usuarios/editar/:Idusuario', (request, response) => {
    let params = Array(
      request.body.name,
      request.params.Idusuario
    );
  
    let query = "UPDATE Usuarios SET name = ? WHERE Idusuario = ?";
  
    connection.query(query, params, (err, results) => {
      if(results) {
        response
          .status(200)
          .json({
            success: true,
            message: "Sucesso",
            data: results
          });
      } else {
        response
          .status(400)
          .json({
            success: false,
            message: "Sem Sucesso",
            data: err
          });
      }
    });
  });

// Essa rota é responsável por deletar um usuário do banco, ela utiliza o Idusuario,como parâmetro na URL
//A query executada é o = DELETE FROM Usuarios WHERE Idusuario = ?, que então deleta o usuário pedido
//se isso for concluido de forma correta  a resposta é enviada com status 200, se não a resposta tem status 400 que mostra uma falha
app.delete('/usuario/deletar/:Idusuario', (request, response) => {
    let params = Array(
      request.params.Idusuario
    );
  
    let query = "DELETE FROM Usuarios WHERE Idusuario = ?";
  
    connection.query(query, params, (err, results) => {
      if(results) {
        response
          .status(200)
          .json({
            success: true,
            message: "Sucesso",
            data: results
          });
      } else {
        response
          .status(400)
          .json({
            success: false,
            message: "Sem Sucesso",
            data: err
          });
      }
    });
  });

// Rota de login de usuários
app.post('/usuario/login', (request, response) => {
  // Pega o email e a senha do corpo da requisição
  const { email, password } = request.body;

  // Query para verificar se o usuário existe e se a senha corresponde
  const query = "SELECT * FROM Usuarios WHERE email = ? AND password = ?";

  // Parâmetros da query
  const params = [email, password];

  // Executa a query
  connection.query(query, params, (err, results) => {
      if (results && results.length > 0) {
          // Se a consulta retornar resultados, o login foi bem-sucedido
          const user = results[0]; // Dados do usuário logado

          // Adiciona o tipo de usuário na resposta
          response
              .status(200)
              .json({
                  success: true,
                  message: "Login com sucesso!",
                  tipo_usuario: user.tipo_usuario, // Retorna o tipo de usuário (admin ou usuario)
                  data: user // Retorna os dados do usuário
              });
      } else {
          // Se a consulta não retornar resultados, o login falhou
          response
              .status(401)
              .json({
                  success: false,
                  message: "Email ou senha incorretos!",
              });
      }
  });
});

  


 //PRODUTOS

 //Essa rota é responsável na função de resgistrar novos produtos no banco de dados, quando receber uma 
 //requisição, o código vai pegar informações do novo produto fornecido conforme o nome dos campos, usando
 // esses dados para uma consulta que adiciona o produto na tabela Produtos, e se isso for concluido
 //o servidor responde com um status 201,se não a resposta terá status 400 sinalizando a falha
 app.post('/produto/cadastrar', (request, response) => {
  let params = [
      request.body.nomeProduto,
      request.body.descricaoProduto,
      request.body.quantidade,
      request.body.valor
  ];
  let query = "INSERT INTO Produtos(nomeProduto, descricaoProduto, quantidade, valor) VALUES (?, ?, ?, ?);";

  connection.query(query, params, (err, results) => {
      if (results) {
          response
              .status(201)
              .json({
                  success: true,
                  message: "Produto cadastrado com sucesso",
                  data: results
              });
      } else {
          response
              .status(400)
              .json({
                  success: false,
                  message: "Erro ao cadastrar produto",
                  data: err
              });
      }
  });
});

//Esse código configura a rota GET com /produtos/listar, ele recupera todos os produtos que estão cadastrados
//dentro do banco de dados e quando isso é feito o código faz uma consulta que seleciona todos os produtos
// da tabela Produtos, e se isso der certo a resposta será enviada conforme o código com o status 200
//se não, em caso de erro vai ser enviada conforme a mensagem de erro com o status 400
app.get('/produtos/listar', (request, response) => {
  const query = "SELECT * FROM Produtos";

  connection.query(query, (err, results) => {
      if (results) {
          response
              .status(200)
              .json({
                  success: true,
                  message: "Produtos listados com sucesso",
                  data: results
              });
      } else {
          response
              .status(400)
              .json({
                  success: false,
                  message: "Erro ao listar produtos",
                  data: err
              });
      }
  });
});


//Esse código faz a rota PUT com /produto/editar/:produtoId, que faz com que atualize as informações do produto
//no banco de dados. O produtoId fornecido na URL da requisição vai identificar o produto que precisa ser modificado
//No Body que é o corpo de requisição o novo nome, descrição, quantidade e valor do produto serão extraídos
// assim puxando a query = UPDATE Produtos SET nomeProduto = ?, descricaoProduto = ?, quantidade = ?, valor = ? WHERE produtoId = ?
//que é usada para atualizar os dados do produto na tabela produtoId. Assim tendo o mesmo processo de sucesso o falha
app.put('/produto/editar/:produtoId', (request, response) => {
  let params = [
      request.body.nomeProduto,
      request.body.descricaoProduto,
      request.body.quantidade,
      request.body.valor,
      request.params.produtoId
  ];

  let query = "UPDATE Produtos SET nomeProduto = ?, descricaoProduto = ?, quantidade = ?, valor = ? WHERE produtoId = ?";

  connection.query(query, params, (err, results) => {
      if (results) {
          response
              .status(200)
              .json({
                  success: true,
                  message: "Produto atualizado com sucesso",
                  data: results
              });
      } else {
          response
              .status(400)
              .json({
                  success: false,
                  message: "Erro ao atualizar produto",
                  data: err
              });
      }
  });
});


//Esse código apresenta a rota DELETE com /Produtos/deletar/:ProdutoId, assim removendo um produto específico
//do banco de dados. Para identificar o produto é usado o ProdutoId é passado na URL para a requisição.
// a query = DELETE FROM Produtos WHERE ProdutoId = ?, é executada para deletar o registro pedido na tabela Produtos
// finalizando com a mensagem de sucesso ou de falha
app.delete('/Produtos/deletar/:ProdutoId', (request, response) => {
  let params = [
      request.params.ProdutoId
  ];

  let query = "DELETE FROM Produtos WHERE ProdutoId = ?";

  connection.query(query, params, (err, results) => {
      if (results) {
          response
              .status(200)
              .json({
                  success: true,
                  message: "Produto deletado com sucesso",
                  data: results
              });
      } else {
          response
              .status(400)
              .json({
                  success: false,
                  message: "Erro ao deletar produto",
                  data: err
              });
      }
  });
});


